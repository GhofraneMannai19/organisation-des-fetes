//add quantity
let plusBtn = Array.from(document.getElementsByClassName('btn-plus'));
for (let i = 0; i < plusBtn.length; i++) {
  plusBtn[i].addEventListener('click', function () {
    plusBtn[i].previousElementSibling.innerText++;
    //Update the total price
    totalPrice();
  });
}

// Variables
const carrito = document.getElementById('carrito');
const cursos = document.getElementById('lista-cursos');
const listaCursos = document.querySelector('#lista-carrito tbody');
const vaciarCarritoBtn = document.getElementById('vaciar-carrito');


// Listeners
cargarEventListeners();
function cargarEventListeners() {
  // Dispara cuando se presiona "Agregar Carrito"
  cursos.addEventListener('click', comprarCurso);
  // Cuando se elimina un curso del carrito
  carrito.addEventListener('click', eliminarCurso);
  // Al Vaciar el carrito
  vaciarCarritoBtn.addEventListener('click', vaciarCarrito);
  // Al cargar el documento, mostrar LocalStorage
  document.addEventListener('DOMContentLoaded', leerLocalStorage);
}

// Funciones
// Función que añade el curso al carrito
function comprarCurso(e) {
  e.preventDefault();
  // Delegation para agregar-carrito
  if(e.target.classList.contains('agregar-carrito')) {
    const curso = e.target.parentElement.parentElement;
    // Enviamos el curso seleccionado para tomar sus datos
    leerDatosCurso(curso);
  }
}

// Lee los datos del curso
function leerDatosCurso(curso) {
  const infoCurso = {
    imagen: curso.querySelector('img').src,
    titulo: curso.querySelector('h4').textContent,
    precio: curso.querySelector('.discount').textContent,
    id: curso.querySelector('a').getAttribute('data-id')
  }
  insertarCarrito(infoCurso);
}

// Muestra el curso seleccionado en el Carrito
function insertarCarrito(curso) {
  const row = document.createElement('tr');
  row.innerHTML = `
  <td>
  <img src="${curso.imagen}" width=100>
  </td>
  <td>${curso.titulo}</td>
  <td>${curso.precio}</td>
  <td>
  <a href="#" class="borrar-curso" data-id="${curso.id}">X</a>
  </td>
  `;
  listaCursos.appendChild(row);
  guardarCursoLocalStorage(curso);
}

// Elimina el curso del carrito en el DOM
function eliminarCurso(e) {
  e.preventDefault();
  let curso,
      cursoId;
  if(e.target.classList.contains('borrar-curso') ) {
    e.target.parentElement.parentElement.remove();
    curso = e.target.parentElement.parentElement;
    cursoId = curso.querySelector('a').getAttribute('data-id');
  }
  eliminarCursoLocalStorage(cursoId);
}

// Elimina los cursos del carrito en el DOM
function vaciarCarrito() {
  // forma lenta
  // listaCursos.innerHTML = '';
  // forma rapida (recomendada)
  while(listaCursos.firstChild) {
    listaCursos.removeChild(listaCursos.firstChild);
  }

  // Vaciar Local Storage
  vaciarLocalStorage();
  return false;
}

// Almacena cursos en el carrito a Local Storage
function guardarCursoLocalStorage(curso) {
  let cursos;
  // Toma el valor de un arreglo con datos de LS o vacio
  cursos = obtenerCursosLocalStorage();
  // el curso seleccionado se agrega al arreglo
  cursos.push(curso);
  localStorage.setItem('cursos', JSON.stringify(cursos) );
}

// Comprueba que haya elementos en Local Storage
function obtenerCursosLocalStorage() {
  let cursosLS;
  // comprobamos si hay algo en localStorage
  if(localStorage.getItem('cursos') === null) {
    cursosLS = [];
  } else {
    cursosLS = JSON.parse( localStorage.getItem('cursos') );
  }
  return cursosLS;
}

// Imprime los cursos de Local Storage en el carrito
function leerLocalStorage() {
  let cursosLS;
  cursosLS = obtenerCursosLocalStorage();
  cursosLS.forEach(function(curso){
  // constrir el template
  const row = document.createElement('tr');
  row.innerHTML = `
  <td>
  <img src="${curso.imagen}" width=100>
  </td>
  <td>${curso.titulo}</td>
  <td>${curso.precio}</td>
  <td>
  <a href="#" class="borrar-curso" data-id="${curso.id}">X</a>
  </td>
  `;
  listaCursos.appendChild(row);
  });
}

// Elimina el curso por el ID en Local Storage
function eliminarCursoLocalStorage(curso) {
  let cursosLS;
  // Obtenemos el arreglo de cursos
  cursosLS = obtenerCursosLocalStorage();
  // Iteramos comparando el ID del curso borrado con los del LS
  cursosLS.forEach(function(cursoLS, index) {
    if(cursoLS.id === curso) {
      cursosLS.splice(index, 1);
    }
  });
  // Añadimos el arreglo actual a storage
  localStorage.setItem('cursos', JSON.stringify(cursosLS) );
}

// Elimina todos los cursos de Local Storage
function vaciarLocalStorage() {
  localStorage.clear();
}
//dimune quantity
let minusBtn = document.getElementsByClassName('btn-moins');
for (let button of minusBtn) {
  button.addEventListener('click', function () {
    if (button.nextElementSibling.innerText > 0) {
      button.nextElementSibling.innerText--;
    }
    //Update the total price
    totalPrice();
  });
}

//Calculate the total price
function totalPrice() {
  let price = document.getElementsByClassName('discount');
  let quantity = document.getElementsByClassName('quantity');
  let sum = 0;
  for (let i = 0; i < price.length; i++) {
    sum += number(price[i].innerText * quantity[i].innerText);
  }
  document.getElementById('prix-total').innerText = sum;
}
//game
var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");
//The game board 1 = walls, 0 = free space, -1 = the goal, 2 = key
var board = [
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
  [1, 0, 1, 0, 0, 0, 0, 0, 1, 0],
  [0, 0, 0, 2, 1, 1, 0, 0, 1, 0],
  [0, 1, 1, 0, 0, 0, 1, 0, 1, 0],
  [0, 0, 1, 1, 1, 1, 1, 0, 1, 0],
  [1, 0, 1, 0, 0, 0, 1, 0, 1, 0],
  [1, 0, 1, 0, 1, 0, 1, 0, 0, 0],
  [1, 0, 1, 0, 1, 0, 0, 1, 1, 0],
  [-1, 0, 1, 0, 1, 1, 0, 0, 0, 0]
];

var player = {
  x: 0,
  y: 0
};
var width = canvas.width;
var blockSize = width / board.length;
var time = 500; //new code
var getKey = false; //new code
document.addEventListener("keydown", control);

function drawWall(x, y) {
  ctx.beginPath();
  ctx.rect(x * blockSize, y * blockSize, blockSize, blockSize);
  ctx.fillStyle = "indigo";
  ctx.fill();
  ctx.closePath();
}

function drawPlayer(x,y){
  var image = document.getElementById("player");
  ctx.drawImage(image,x*blockSize,y*blockSize,blockSize,blockSize);
}

function drawGoal(x,y){
  if (getKey == true) { //new code
  var image = document.getElementById("goal");
  ctx.drawImage(image,x*blockSize,y*blockSize,blockSize,blockSize)
  }
  else if (getKey == false) { //new code
    var image = document.getElementById("blank");
  ctx.drawImage(image,x*blockSize,y*blockSize,blockSize,blockSize);
  }

}

function drawKey(x,y){
  var image = document.getElementById("key");
  ctx.drawImage(image,x*blockSize,y*blockSize,blockSize,blockSize);
}

function canMove(x, y) {
  if (
    y >= 0 &&
    y < board.length &&
    x >= 0 &&
    x < board[y].length &&
    board[y][x] != 1
  )
    return true;
  else return false; //new code
}

function checkWin(x,y) {
  if (board[y][x] == -1 && getKey == true) {
    alert("congratulation you are the most lucky girl or boy you win a 20% reduction"); //win game message
    clearInterval(a);
  } else if (board[y][x] == -1 && getKey == false) {
    alert("Game Over! You need to get the key"); //new code
  }
}

function control(clicked_id) { // new code
  if (time > 0 && board[player.y][player.x] != -1) {
    if (
      (clicked_id == "up" || clicked_id.which == 38) &&
      canMove(player.x, player.y - 1) &&
      !checkWin(player.x, player.y - 1) //Up arrow
    )
      player.y--;
    else if (
      (clicked_id == "down" || clicked_id.which == 40) &&
      canMove(player.x, player.y + 1) &&
      !checkWin(player.x, player.y + 1) // down arrow
    )
      player.y++;
    else if (
      (clicked_id == "left" || clicked_id.which == 37) &&
      canMove(player.x - 1, player.y) &&
      !checkWin(player.x - 1, player.y)
    )
      player.x--;
    else if (
      (clicked_id == "right" || clicked_id.which == 39) &&
      canMove(player.x + 1, player.y) &&
      !checkWin(player.x + 1, player.y)
    )
      player.x++;
    checkGetKey(player.x, player.y);
    draw();
  }
}

function timer() { //newcode
  if (time !=0) {
    time--;
    document.getElementById("showTimer").innerHTML = "___Type here: " + time + "s";
  } else {
    alert("______ Game Over")
    document.location.assign(location);
  }
}

function checkGetKey(x, y) {
  if (board[y][x] == 2) {
    board[y][x] = 0;
    getKey = true;
    document.getElementById("showHint").innerHTML = "____ Got it!";
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawPlayer(player.x,player.y);
  for (var y = 0; y < board.length; y++) {
    for (var x = 0; x < board[y].length; x++) {
      if (board[y][x] == 1) {
        drawWall(x, y);
      } else if (board[y][x] == -1) {
        drawGoal(x,y);
      } else if (board[y][x] == 2) {
        drawKey(x,y);
      }
    }
  }
  drawPlayer(); //newcode
}
draw();


//Delete a product
let deleteBtn = Array.from(document.querySelectorAll('.btn-delete'));
deleteBtn.forEach((el) =>
  el.addEventListener('click', function () {
    el.parentElement.parentElement.remove();
    totalPrice();
  })
);
// for (let i = 0; i < deleteBtn.length; i++) {
//   deleteBtn[i].addEventListener('click', function () {
//     deleteBtn[i].parentElement.parentElement.remove();
//     totalPrice();
//   });
// }

// //Like a product
let likeBtn = document.querySelectorAll('.btn-like');
let heart = document.querySelectorAll('.like');
for (let i = 0; i < likeBtn.length; i++) {
  likeBtn[i].addEventListener('click', function () {
    if (heart[i].style.fill === 'white') {
      heart[i].style.fill = 'pink';
    } else {
      heart[i].style.fill = 'white';
    }
  });
}
//booking
	